<?php

/** Author : Neha Khemchandani
* Date created : 5th February,2023
* Portfolio : https://nehakhemchandani.com
**/

namespace MauticPlugin\MauticTextlocalBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

/**
 * Class MauticTextlocalBundle.
 */
class MauticTextlocalBundle extends PluginBundleBase
{
}
