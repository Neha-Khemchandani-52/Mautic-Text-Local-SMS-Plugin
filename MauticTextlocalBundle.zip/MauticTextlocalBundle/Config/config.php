<?php
## Author : Neha Khemchandani
## Date created : 5th February,2023
## Portfolio : https://nehakhemchandani.com

return [
    'name'        => 'MauticTextlocalBundle',
    'description' => 'Textlocal integration',
    'author'      => 'Neha Khemchandani',
    'version'     => '0.0.2',
    'services' => [
        'events'  => [],
        'forms'   => [
        ],
        'helpers' => [],
        'other'   => [
            'mautic.sms.transport.textlocal' => [
                'class'     => \MauticPlugin\MauticTextlocalBundle\Transport\TextlocalTransport::class,
                'arguments' => [
                    'mautic.helper.integration',
                    'monolog.logger.mautic',
                    'mautic.http.client',
                ],
                'alias'        => 'mautic.sms.config.textlocal.transport',
                'tag'          => 'mautic.sms_transport',
                'tagArguments' => [
                    'integrationAlias' => 'Textlocal',
                ],
            ],
        ],
        'models'       => [],
        'integrations' => [
            'mautic.integration.textlocal' => [
                'class' => \MauticPlugin\MauticTextlocalBundle\Integration\TextlocalIntegration::class,
                'arguments' => [
                    'event_dispatcher',
                    'mautic.helper.cache_storage',
                    'doctrine.orm.entity_manager',
                    'session',
                    'request_stack',
                    'router',
                    'translator',
                    'logger',
                    'mautic.helper.encryption',
                    'mautic.lead.model.lead',
                    'mautic.lead.model.company',
                    'mautic.helper.paths',
                    'mautic.core.model.notification',
                    'mautic.lead.model.field',
                    'mautic.plugin.model.integration_entity',
                    'mautic.lead.model.dnc',
                ],
            ],
        ],
    ],
    'routes'     => [],
    'menu'       => [
        'main' => [
            'items' => [
                'mautic.sms.smses' => [
                    'route'    => 'mautic_sms_index',
                    'access'   => ['sms:smses:viewown', 'sms:smses:viewother'],
                    'parent'   => 'mautic.core.channels',
                    'checks'   => [
                        'integration' => [
                            'Textlocal' => [
                                'enabled' => true,
                            ],
                        ],
                    ],
                    'priority' => 70,
                ],
            ],
        ],
    ],
    'parameters' => [],
];

